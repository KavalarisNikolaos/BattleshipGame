package GameFunctionality;


public enum Direction {
    Horizontal,
    Vertical;
}