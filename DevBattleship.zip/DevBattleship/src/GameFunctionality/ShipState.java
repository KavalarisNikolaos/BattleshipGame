package GameFunctionality;

public enum ShipState {
    NO_HIT,
    WOUNDED,
    SUNK

}